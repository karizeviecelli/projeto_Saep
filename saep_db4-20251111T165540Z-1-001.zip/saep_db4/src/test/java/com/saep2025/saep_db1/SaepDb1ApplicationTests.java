package com.saep2025.saep_db1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaepDb1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
