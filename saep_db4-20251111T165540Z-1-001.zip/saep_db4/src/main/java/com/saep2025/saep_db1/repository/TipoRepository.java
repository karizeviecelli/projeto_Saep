package com.saep2025.saep_db1.repository;


import com.saep2025.saep_db1.model.Tipo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoRepository extends JpaRepository<Tipo, Long> {}
